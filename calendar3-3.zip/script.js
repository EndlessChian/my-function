const isLeapYear = (year) => {
    return(
        (year % 4 === 0 && year % 100 !== 0 && year % 400 !== 0) || 
        (year % 100 === 0 && year % 400 === 0)
    );
};
const getFebDays = (year) => {
    return isLeapYear(year) ? 29 : 28;
};
let calendar = document.querySelector('.calendar');
const month_names = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
];
let month_picker = document.querySelector('#month-picker');
const dayTextFormate = document.querySelector('.day-text-formate');
const timeFormate = document.querySelector('.time-formate');
const dateFormate = document.querySelector('.date-formate');
const foot = document.querySelector('.calendar-footer');
const height = screen.availHeight - calendar.offsetTop * 2 - 30 - 90;

month_picker.onclick = () => {
    month_list.classList.remove('hideonce');
    month_list.classList.remove('hide');
    month_list.classList.add('show');
    dayTextFormate.classList.remove('showtime');
    dayTextFormate.classList.add('hidetime');
    timeFormate.classList.remove('showtime');
    timeFormate.classList.add('hideTime');
    dateFormate.classList.remove('showtime');
    dateFormate.classList.add('hideTime');
};

const generateCalendar = (month,year) => {
    let calendar_days = document.querySelector('.calendar-days');
    calendar_days.innerHTML = '';
    let calendar_header_year = document.querySelector('#year');
    let days_of_month = [
        31,
        getFebDays(year),
        31,
        30,
        31,
        30,
        31,
        31,
        30,
        31,
        30,
        31
    ];
    let currentDate = new Date();
    month_picker.innerHTML = month_names[month];
    calendar_header_year.innerHTML = year;
    let first_day = new Date(year,month);
    let i=1,j=days_of_month[month] + first_day.getDate();
    for (; i<j; i++){
        let day = document.createElement('div');
        if (i >= first_day.getDate()){
            var getday = i - first_day.getDay();
            if(getday>0){
                day.innerHTML = getday;
                if (getday === currentDate.getDate() && year === currentDate.getFullYear() && month === currentDate.getMonth()
                ) day.classList.add('current-date');
            }else j++;
        }
        calendar_days.appendChild(day);
    }
    var cols = Math.ceil((j-1)/7);
    //foot.style.height = (6 - cols) * (33 + 2) + 47 + 'px';
    foot.style.height = height - (calendar.scrollHeight - foot.scrollHeight) + 'px';//put generateCalendar() after month_names-209
};
let month_list = calendar.querySelector('.month-list');

document.querySelector('#pre-year').onclick = () => {
    --currentYear.value;
    generateCalendar(currentMonth.value, currentYear.value);
};
document.querySelector('#next-year').onclick = () => {
    ++currentYear.value;
    generateCalendar(currentMonth.value, currentYear.value);
};

let currentDate = new Date();
let currentMonth = {value : currentDate.getMonth()};
let currentYear = {value : currentDate.getFullYear()};
//generateCalendar(currentMonth.value, currentYear.value);
document.getElementById('today').onclick = () => generateCalendar(currentDate.getMonth(), currentDate.getFullYear());
function isMobile(){
    let getarr = ['Android', 'iPhone', 'SymbianOS', 'Windows Phone', 'iPad', 'iPod'].filter(i => navigator.userAgent.includes(i));
    console.log(getarr);
    return!!getarr.length
}
if(isMobile()){
    var body = document.querySelector('body');
    document.querySelector('.time-formate').style.fontSize = '1.1rem';
    document.querySelector('.date-text-formate').style.fontSize = '1rem';
    document.querySelector('div>pre').style.margin = '18px 38px';
    document.querySelector('.month-picker').style.padding = '6px 0';
    calendar.style.padding = '10px 10px 20px';
    body.style.fontSize = '12px';
}
month_names.forEach((e, index) => {
    let month = document.createElement('div');
    month.innerHTML = `<div>${e}</div>`;
    month_list.append(month);
    month.onclick = () => {
        currentMonth.value = index;
        generateCalendar(currentMonth.value, currentYear.value);
        month_list.classList.replace('show', 'hide');
        dayTextFormate.classList.remove('hidetime');
        dayTextFormate.classList.add('showtime');
        timeFormate.classList.remove('hideTime');
        timeFormate.classList.add('showtime');
        dateFormate.classList.remove('hideTime');
        dateFormate.classList.add('showtime');
    };
});
month_list.classList.add('hideonce');
const todayShowTime = document.querySelector('.time-formate');
const todayShowDate = document.querySelector('.date-formate');

generateCalendar(currentMonth.value, currentYear.value);

function showtodate(){
    const currshowDate = new Date();
    const showCurrentDateOption = {
        year : 'numeric',
        month : 'long',
        day : 'numeric',
        weekday : 'long',
    };
    const currentDateFormate = new Intl.DateTimeFormat(
        'en-US',
        showCurrentDateOption
    ).format(currshowDate);
    todayShowDate.textContent = currentDateFormate;
    return(currshowDate.getDate());
};
let thedate = {value : showtodate()};
setInterval(() => {
    const timer = new Date();
    const option = {
        hour : 'numeric',
        minute : 'numeric',
        second : 'numeric',
    };
    const formateTimer = new Intl.DateTimeFormat('en-us', option).format(timer);
    let time = `${`${timer.getHours()}`.padStart(
        2,
        '0'
    )}:${`${timer.getMinutes()}`.padStart(
        2,
        '0'
    )}:${`${timer.getSeconds()}`.padStart(2,'0')}`;
    todayShowTime.textContent = formateTimer;
    if(thedate.value !== timer.getDate()) thedate.value=showtodate();
},1000);